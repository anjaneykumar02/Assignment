import 'package:flutter/material.dart';

class AppColors {
  static var boarderColor = Colors.black;
  static var appColorPrimary = const Color.fromARGB(255, 76, 167, 242);
}
