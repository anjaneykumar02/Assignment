package com.example.userinfo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
